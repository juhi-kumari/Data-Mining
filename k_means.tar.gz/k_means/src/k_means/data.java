package k_means;

public class data {
    float[] a = new float[4];
    
    data(String line){
        String delims = "[,]";
        //System.out.println("success1");
        String[] tokens = line.split(delims);
        for(int i=0; i < 4; i++){
            //System.out.println(tokens[i]);
            a[i] = Float.valueOf(tokens[i]);
        }
        //System.out.println("success2");
    }
    
    double distance(data center){
        double f = 0;
        for(int i = 0; i < 4; i++){
            f += Math.pow((center.a[i] - a[i]), 2);
        }
        f = Math.sqrt(f);
        return f;
    }
    void print(){
        for(int i = 0; i < 4; i++){
            System.out.print(a[i]+" ");
        }
        System.out.println();
        //System.out.println(a[0]+" "+daa.a[1]+" "+daa.a[2]+" "+daa.a[3]);
    }
}
