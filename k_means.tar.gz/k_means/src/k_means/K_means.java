/*
Date: 3rd February, 2016
Created by: IIT2013153

Question: Implement K-means clustering on Iris Data Set
Hint: 
    Clusters the data into k groups where k  is predefined.
    Select k points at random as cluster centers.
    Assign objects to their closest cluster center according to the Euclidean distance function.
    Calculate the centroid or mean of all objects in each cluster.
    Repeat steps 2, 3 and 4 until the same points are assigned to each cluster in consecutive rounds.


For this, the program will read the data from a file. 
Then, we will calculate the distance between different points and hence cluster them accordingly.
At last means has to be taken out from each cluster.
Just for now I am taking 3 clusters


for now on this code is not complete. 
Also, u gotta ensure that every time the center is updates, i.e. take means everytime a data entry has been done in the cluster.
Other than this, output format and array of arraylist has to be seen.
Quite array of arraylist seems complicated. So watch out carefully.
Thats it for today....
*/

package k_means;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 *
 * @author iit2013153
 */
public class K_means {

    public static void main(String[] args) {
        //for now assuming there are 3 clusters
        int n = 3;//total no of clusters
        ArrayList<data> data_set1=new ArrayList<data>();
        ArrayList<data> data_set2=new ArrayList<data>();
        ArrayList<data> data_set3=new ArrayList<data>();
        //ArrayList<data> data_set4=new ArrayList<data>();
        data[] dataset = new data[2000];
        
        ArrayList<ArrayList<data>> data_array= new ArrayList<ArrayList<data>>(3);
        int d=0;
        
        String file = "iris.txt";
        //int d = 0;
        
        try {

            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            String line;
        
            while ((line = br.readLine()) != null) {
                
                if((line == null) || (line.isEmpty())){
                    continue;
                }
                System.out.println(line);
                dataset[d] = new data(line);
                //System.out.println("success"+ d);
                if(d == 0){
                    data_set1.add(dataset[d]);
                }
                
                if(d == 1){
                    data_set2.add(dataset[d]);
                }
                if(d == 2){
                    data_set3.add(dataset[d]);
                }
                
                d++;
            
            }
            br.close();

        } catch (IOException e) {
            System.out.println("ERROR: unable to read file " + file);
            e.printStackTrace();   
        }
        
        double[] distance = new double[n];
        /*for(int i = 0; i < n; i++){
            data_array[i].add(data[i]);
        }*/
        for(int i = 3; i < d; i++) {
            distance[0] = dataset[i].distance(data_set1.get(0));
            distance[1] = dataset[i].distance(data_set2.get(0));
            distance[2] = dataset[i].distance(data_set3.get(0));
            if(distance[0] < distance[1]){
                if(distance[0] < distance[2]){
                    data_set1.add(dataset[i]);
                } else {
                    data_set3.add(dataset[i]);
                }
                
            }else {
                //distance[1] is smaller than 0
                if(distance[1] < distance[2]){
                    data_set2.add(dataset[i]);
                } else {
                    data_set3.add(dataset[i]);
                }
                
            }
        }
        
        for(int j = 0; j < n; j++){
            data_array[i].add(dataset[i]);
        }
        System.out.println("first cluster");
        data daa;
        for(int i = 0; i < data_set1.size(); i++){
            daa = data_set1.get(i);
            daa.print();
            //System.out.println(daa.a[0]+" "+daa.a[1]+" "+daa.a[2]+" "+daa.a[3]);
        }
        
    }
    
}
